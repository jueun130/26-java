import java.util.Scanner;

public class Grade {
	
	//속성
	String name;
	int score1, score2, score3;

	//인자 생성자
	public Grade(String name, int score1, int score2, int score3) {
		this.name = name;
		this.score1 = score1;
		this.score2 = score2;
		this.score3 = score3;
	}
	
	//메소드
	public String getName() {
		return name;
	}
	
	public int getAverage() {
		int sum = score1 + score2 + score3;
		int avg = sum / 3;
		return avg;
	}
		
		

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.print("이름,	자바,	웹프로그래밍,	운영체제 순으로 점수 입력>>");
		String	name = scan.next();
		int	java = scan.nextInt();
		int	web	= scan.nextInt();
		int	os = scan.nextInt();
		Grade st = new	Grade(name,	java, web, os);
		System.out.print(st.getName() +	"의 평균은 " + st.getAverage());
		scan.close();

	}

}
