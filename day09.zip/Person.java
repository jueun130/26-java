
public class Person {

	String name;
	int phone;
	
	public Person(String name, int phone) {
		this.name = name;
		this.phone = phone;
	}
	
}

