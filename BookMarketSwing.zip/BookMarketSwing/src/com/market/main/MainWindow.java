package com.market.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.market.cart.Cart;
import com.market.page.GuestInfoPage;
import com.market.page.CartAddItemPage;
import com.market.page.CartItemListPage;

public class MainWindow extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static Cart mCart;
    static JPanel mMenuPanel, mPagePanel;

    public MainWindow(String title, int x, int y, int width, int height) {
        setTitle(title);
        setBounds(x, y, width, height);
        setLayout(null);
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - 1000) / 2, (screenSize.height - 750) / 2);
        
        mCart = new Cart();
        
        // 상단 메뉴 버튼 패널 초기화 영역
        mMenuPanel = new JPanel();
        mMenuPanel.setBounds(0, 20, width, 130);
        menuIntroduction();
        add(mMenuPanel);
        
        // 하단 서브 화면들이 교체 표출될 컨테이너 패널 영역
        mPagePanel = new JPanel();
        mPagePanel.setBounds(0, 150, width, height - 150);
        add(mPagePanel);
        
        setVisible(true);
        setResizable(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void menuIntroduction() {
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);

        // 1번 버튼: 고객 정보 확인하기
        JButton bt1 = new JButton("고객 정보 확인하기", new ImageIcon("./images/1.png"));
        bt1.setFont(ft);
        mMenuPanel.add(bt1);
        bt1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mPagePanel.removeAll();
                mPagePanel.add("고객 정보 확인", new GuestInfoPage(mPagePanel));
                mPagePanel.revalidate();
                mPagePanel.repaint();
            }
        });

        // 2번 버튼: 장바구니 상품 목록 보기
        JButton bt2 = new JButton("장바구니 상품 목록 보기", new ImageIcon("./images/2.png"));
        bt2.setFont(ft);
        mMenuPanel.add(bt2);
        bt2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (mCart.mCartItem.isEmpty()) {
                    JOptionPane.showMessageDialog(bt2, "장바구니에 항목이 없습니다", "장바구니 상품 목록 보기", JOptionPane.ERROR_MESSAGE);
                } else {
                    mPagePanel.removeAll();
                    mPagePanel.add("장바구니 상품 목록 보기", new CartItemListPage(mPagePanel, mCart));
                    mPagePanel.revalidate();
                    mPagePanel.repaint();
                }
            }
        });

        // 4번 버튼: 장바구니에 항목 추가하기
        JButton bt4 = new JButton("장바구니에 항목 추가하기", new ImageIcon("./images/4.png"));
        bt4.setFont(ft);
        mMenuPanel.add(bt4);
        bt4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mPagePanel.removeAll();
                com.market.bookitem.BookInIt.init(); // 도서 로드
                mPagePanel.add("장바구니에 항목 추가하기", new CartAddItemPage(mPagePanel, mCart));
                mPagePanel.revalidate();
                mPagePanel.repaint();
            }
        });
        
        // (이와 같이 나머지 bt3, bt5, bt6, bt7, bt8, bt9 버튼 컴포넌트들도 유사하게 구현 패널에 추가 처리됩니다.)
    }
}
