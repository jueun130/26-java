package com.market.main;

public class Welcome {
    public static void main(String[] args) {
        // 가장 먼저 사용자 정보를 입력받는 프레임(GuestWindow)을 생성 및 호출합니다.
        new GuestWindow("고객 정보 입력", 0, 0, 1000, 750);
    }
}


//AI는 오류 수정(The serializable class CartAddItemPage does not declare a static final serialVersionUID field of type long/The serializable class CartItemListPage does not declare a static final serialVersionUID/com.market.main의 MainWindow.java에서 The serializable class MainWindow does not declare a static final serialVersionUID field of type long
//MainWindow에서 The import com.market.page.CartItemListPage cannot be resolved/com.market.main의 GuestWindow에서 The serializable class GuestWindow does not declare a static final serialVersionUID field of type
//long등과 package, class 구성 등에 사용하였습니다.