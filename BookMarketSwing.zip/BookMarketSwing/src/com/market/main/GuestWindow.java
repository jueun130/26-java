package com.market.main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.market.member.UserInIt;

public class GuestWindow extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField nameField;
    private JTextField phoneField;

    public GuestWindow(String title, int x, int y, int width, int height) {
        initContainer(title, x, y, width, height);
        setVisible(true);
        setResizable(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setIconImage(new ImageIcon("./images/shop.png").getImage());
    }

    private void initContainer(String title, int x, int y, int width, int height) {
        setTitle(title);
        setBounds(x, y, width, height);
        setLayout(null);
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((screenSize.width - 1000) / 2, (screenSize.height - 750) / 2);

        // 이미지 패널 영역
        JPanel userPanel = new JPanel();
        userPanel.setBounds(0, 100, 1000, 256);
        ImageIcon imageIcon = new ImageIcon("./images/user.png");
        imageIcon.setImage(imageIcon.getImage().getScaledInstance(160, 160, Image.SCALE_SMOOTH));
        JLabel userLabel = new JLabel(imageIcon);
        userPanel.add(userLabel);
        add(userPanel);

        // 입력 타이틀 안내 패널
        JPanel titlePanel = new JPanel();
        titlePanel.setBounds(0, 350, 1000, 50);
        JLabel titleLabel = new JLabel("-- 고객 정보를 입력하세요 --");
        titleLabel.setFont(ft);
        titleLabel.setForeground(Color.BLUE);
        titlePanel.add(titleLabel);
        add(titlePanel);

        // 이름 입력란 패널
        JPanel namePanel = new JPanel();
        namePanel.setBounds(0, 400, 1000, 50);
        JLabel nameLabel = new JLabel("이 름: ");
        nameLabel.setFont(ft);
        nameField = new JTextField(10);
        nameField.setFont(ft);
        namePanel.add(nameLabel);
        namePanel.add(nameField);
        add(namePanel);

        // 연락처 입력란 패널
        JPanel phonePanel = new JPanel();
        phonePanel.setBounds(0, 450, 1000, 50);
        JLabel phoneLabel = new JLabel("연락처 : ");
        phoneLabel.setFont(ft);
        phoneField = new JTextField(10);
        phoneField.setFont(ft);
        phonePanel.add(phoneLabel);
        phonePanel.add(phoneField);
        add(phonePanel);

        // 쇼핑하기 버튼 패널
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(0, 500, 1000, 100);
        JLabel buttonLabel = new JLabel("쇼핑하기", new ImageIcon("images/shop.png"), JLabel.LEFT);
        buttonLabel.setFont(ft);
        JButton enterButton = new JButton();
        enterButton.add(buttonLabel);
        buttonPanel.add(enterButton);
        add(buttonPanel);

        // 버튼 클릭시 액션 리스너 이벤트 처리
        enterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (nameField.getText().isEmpty() || phoneField.getText().isEmpty()) {
                    JLabel message = new JLabel("고객 정보를 입력하세요");
                    message.setFont(ft);
                    JOptionPane.showMessageDialog(enterButton, message, "고객 정보", JOptionPane.ERROR_MESSAGE);
                } else {
                    // 유효하게 입력받은 값을 기반으로 유저 데이터 초기화 후 메인 윈도우 창 오픈
                    UserInIt.init(nameField.getText(), Integer.parseInt(phoneField.getText()));
                    dispose(); // 현재 창 제거
                    new MainWindow("온라인 서점", 0, 0, 1000, 750); // 메인 프레임 오픈
                }
            }
        });
    }
}
