package com.market.cart;

import com.market.bookitem.Book;
import java.util.ArrayList;

public class Cart implements CartInterface {
    public ArrayList<CartItem> mCartItem = new ArrayList<CartItem>();
    public static int mCartCount = 0;

    public Cart() {}

    public ArrayList<CartItem> getmCartItem() { return mCartItem; }

    public void printBookList(Book[] booklist) {
        for (int i = 0; i < booklist.length; i++) {
            System.out.print(booklist[i].getBookId() + " | ");
            System.out.print(booklist[i].getName() + " | ");
            System.out.print(booklist[i].getUnitPrice() + " | ");
            System.out.print(booklist[i].getAuthor() + " | ");
            System.out.println(booklist[i].getReleaseDate());
        }
    }

    public void insertBook(Book book) {
        CartItem item = new CartItem(book);
        mCartItem.add(item);
        mCartCount++;
    }

    public void deleteBook() {
        mCartItem.clear();
        mCartCount = 0;
    }

    public boolean isCartInBook(String bookId) {
        boolean flag = false;
        for (int i = 0; i < mCartItem.size(); i++) {
            if (bookId.equals(mCartItem.get(i).getBookID())) {
                mCartItem.get(i).setQuantity(mCartItem.get(i).getQuantity() + 1);
                flag = true;
            }
        }
        return flag;
    }

    public void removeCart(int numId) {
        if (numId >= 0 && numId < mCartItem.size()) {
            mCartItem.remove(numId);
            mCartCount--;
        }
    }
}
