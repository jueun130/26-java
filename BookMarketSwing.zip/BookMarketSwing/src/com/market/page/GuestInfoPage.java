package com.market.page;

import javax.swing.*;
import java.awt.*;
import com.market.member.UserInIt;

public class GuestInfoPage extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GuestInfoPage(JPanel panel) {
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);
        setLayout(null);
        Rectangle rect = panel.getBounds();
        setPreferredSize(rect.getSize());

        JPanel namePanel = new JPanel();
        namePanel.setBounds(0, 100, 1000, 50);
        JLabel nameLabel = new JLabel("이름: ");
        nameLabel.setFont(ft);
        
        JLabel nameField = new JLabel();
        nameField.setText(UserInIt.getmUser().getName());
        nameField.setFont(ft);
        namePanel.add(nameLabel);
        namePanel.add(nameField);
        add(namePanel);

        JPanel phonePanel = new JPanel();
        phonePanel.setBounds(0, 150, 1000, 100);
        JLabel phoneLabel = new JLabel("연락처: ");
        phoneLabel.setFont(ft);
        
        JLabel phoneField = new JLabel();
        phoneField.setText(String.valueOf(UserInIt.getmUser().getPhone()));
        phoneField.setFont(ft);
        phonePanel.add(phoneLabel);
        phonePanel.add(phoneField);
        add(phonePanel);
    }
}
