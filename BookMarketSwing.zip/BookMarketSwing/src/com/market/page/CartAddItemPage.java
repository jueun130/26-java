package com.market.page;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import com.market.bookitem.Book;
import com.market.bookitem.BookInIt;
import com.market.cart.Cart;

public class CartAddItemPage extends JPanel {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ImageIcon imageBook;
    int mSelectRow = 0;
    Cart mCart;

    public CartAddItemPage(JPanel panel, Cart cart) {
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);
        this.mCart = cart;
        setLayout(null);
        Rectangle rect = panel.getBounds();
        setPreferredSize(rect.getSize());

        // 좌측 도서 이미지 패널
        JPanel imagePanel = new JPanel();
        imagePanel.setBounds(20, 0, 300, 400);
        imageBook = new ImageIcon("./images/ISBN1234.jpg");
        imageBook.setImage(imageBook.getImage().getScaledInstance(250, 300, Image.SCALE_DEFAULT));
        JLabel label = new JLabel(imageBook);
        imagePanel.add(label);
        add(imagePanel);

        // 우측 JTable 테이블 스크롤 패널
        JPanel tablePanel = new JPanel();
        tablePanel.setBounds(300, 0, 700, 400);
        add(tablePanel);

        ArrayList<Book> booklist = BookInIt.getmBookList();
        Object[] tableHeader = {"도서ID", "도서명", "가격", "저자", "설명", "분야", "출판일"};
        Object[][] content = new Object[booklist.size()][tableHeader.length];
        
        for (int i = 0; i < booklist.size(); i++) {
            Book bookitem = booklist.get(i);
            content[i][0] = bookitem.getBookId();
            content[i][1] = bookitem.getName();
            content[i][2] = bookitem.getUnitPrice();
            content[i][3] = bookitem.getAuthor();
            content[i][4] = bookitem.getDescription();
            content[i][5] = bookitem.getCategory();
            content[i][6] = bookitem.getReleaseDate();
        }

        JTable bookTable = new JTable(content, tableHeader);
        bookTable.setRowSelectionInterval(0, 0);
        JScrollPane jScrollPane = new JScrollPane();
        jScrollPane.setPreferredSize(new Dimension(600, 350));
        jScrollPane.setViewportView(bookTable);
        tablePanel.add(jScrollPane);

        // 하단 버튼 제어용 패널
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(0, 400, 1000, 400);
        JLabel buttonLabel = new JLabel("장바구니에 담기");
        buttonLabel.setFont(ft);
        JButton addButton = new JButton();
        addButton.add(buttonLabel);
        buttonPanel.add(addButton);
        add(buttonPanel);

        // 마우스 클릭 시 선택 행 변경에 맞는 표지 이미지 동적 갱신 처리 이벤트 리스너
        bookTable.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                int row = bookTable.getSelectedRow();
                mSelectRow = row;
                Object value = bookTable.getValueAt(row, 0);
                String str = value + ".jpg";
                imageBook = new ImageIcon("./images/" + str);
                imageBook.setImage(imageBook.getImage().getScaledInstance(250, 300, Image.SCALE_DEFAULT));
                JLabel label = new JLabel(imageBook);
                imagePanel.removeAll();
                imagePanel.add(label);
                imagePanel.revalidate();
                imagePanel.repaint();
            }
            public void mousePressed(MouseEvent e) {}
            public void mouseReleased(MouseEvent e) {}
            public void mouseEntered(MouseEvent e) {}
            public void mouseExited(MouseEvent e) {}
        });

        // 장바구니에 담기 최종 기능 리스너 구현부
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int select = JOptionPane.showConfirmDialog(addButton, "장바구니에 추가하겠습니까?");
                if (select == 0) {
                    int numId = mSelectRow;
                    if (!mCart.isCartInBook(booklist.get(numId).getBookId())) {
                        mCart.insertBook(booklist.get(numId));
                    }
                    JOptionPane.showMessageDialog(addButton, "추가했습니다");
                }
            }
        });
    }
}
