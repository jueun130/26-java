package com.market.page;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import com.market.cart.Cart;
import com.market.cart.CartItem;

public class CartItemListPage extends JPanel {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable cartTable;
    private Object[][] content;
    private static Cart mCart;

    public CartItemListPage(JPanel panel, Cart cart) {
        Font ft = new Font("함초롬돋움", Font.BOLD, 15);
        mCart = cart;
        
        setLayout(null);
        Rectangle rect = panel.getBounds();
        setPreferredSize(rect.getSize());

        // 1. 장바구니 목록을 보여줄 테이블 패널 영역
        JPanel tablePanel = new JPanel();
        tablePanel.setBounds(0, 0, 1000, 400);
        add(tablePanel);

        // 테이블 헤더 구성
        Object[] tableHeader = {"도서ID", "도서명", "단가", "수량", "총금액"};
        
        // 장바구니 아이템 리스트 가져오기
        ArrayList<CartItem> cartitems = mCart.getmCartItem();
        content = new Object[cartitems.size()][tableHeader.length];
        
        // 테이블 데이터 채우기 및 총 금액 계산
        int totalAmount = 0;
        for (int i = 0; i < cartitems.size(); i++) {
            CartItem item = cartitems.get(i);
            content[i][0] = item.getBookID();
            content[i][1] = item.getItemBook().getName();
            content[i][2] = item.getItemBook().getUnitPrice();
            content[i][3] = item.getQuantity();
            content[i][4] = item.getTotalPrice();
            totalAmount += item.getTotalPrice(); // 총 금액 누적
        }

        // JTable 생성 및 스크롤 패널 추가
        cartTable = new JTable(content, tableHeader);
        JScrollPane jScrollPane = new JScrollPane();
        jScrollPane.setPreferredSize(new Dimension(900, 350));
        jScrollPane.setViewportView(cartTable);
        tablePanel.add(jScrollPane);

        // 2. 총 금액 표시 패널 영역
        JPanel totalPanel = new JPanel();
        totalPanel.setBounds(0, 400, 1000, 50);
        JLabel totalLabel = new JLabel("총금액: " + totalAmount + " 원");
        totalLabel.setFont(new Font("함초롬돋움", Font.BOLD, 20));
        totalLabel.setForeground(Color.RED);
        totalPanel.add(totalLabel);
        add(totalPanel);

        // 3. 기능 버튼 패널 영역 (삭제, 장바구니 비우기, 새로고침 등)
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBounds(0, 450, 1000, 100);
        add(buttonPanel);

        // [선택 항목 삭제] 버튼
        JButton clearButton = new JButton("장바구니 비우기");
        clearButton.setFont(ft);
        buttonPanel.add(clearButton);

        JButton removeButton = new JButton("장바구니 항목 삭제하기");
        removeButton.setFont(ft);
        buttonPanel.add(removeButton);

        // 장바구니 비우기 버튼 이벤트 처리
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (mCart.mCartItem.isEmpty()) {
                    JOptionPane.showMessageDialog(clearButton, "장바구니가 이미 비어있습니다.");
                    return;
                }
                
                int select = JOptionPane.showConfirmDialog(clearButton, "장바구니를 정말 모두 비우시겠습니까?");
                if (select == 0) { // '예' 선택 시
                    mCart.deleteBook();
                    JOptionPane.showMessageDialog(clearButton, "장바구니를 모두 비웠습니다.");
                    
                    // 화면 새로고침 (MainWindow의 패널을 다시 그립니다)
                    panel.removeAll();
                    panel.add("장바구니 상품 목록 보기", new CartItemListPage(panel, mCart));
                    panel.revalidate();
                    panel.repaint();
                }
            }
        });

        // 장바구니 항목 삭제하기 버튼 이벤트 처리
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = cartTable.getSelectedRow();
                if (row == -1) {
                    JOptionPane.showMessageDialog(removeButton, "삭제할 항목을 테이블에서 먼저 선택해주세요.");
                } else {
                    int select = JOptionPane.showConfirmDialog(removeButton, "선택한 항목을 삭제하시겠습니까?");
                    if (select == 0) { // '예' 선택 시
                        mCart.removeCart(row);
                        JOptionPane.showMessageDialog(removeButton, "선택한 항목이 삭제되었습니다.");
                        
                        // 화면 새로고침
                        panel.removeAll();
                        panel.add("장바구니 상품 목록 보기", new CartItemListPage(panel, mCart));
                        panel.revalidate();
                        panel.repaint();
                    }
                }
            }
        });
    }
}
