package day07;

//Circle
class Circle{
	int radius;
	String name;
	
	public Circle() { //기본 생성자
		this(0,"");
		}
	public Circle(int radius) {
		this(radius,"불고기피자");
	}
	
	//인자(매개변수_2개) 생성자...
	public Circle(int radius, String name) {
		this.radius = radius;
		this.name = name;
	}
	
	
	
	public double getArea() { //원의 면적 계산 메소드
		return 3.14*radius*radius;
	}
}


public class Pizza {

	public static void main(String[] args) {
		//1. 레퍼런스 변수 pizza 선언
		Circle pizza,pizza2;
		//2. Circle 객체 생성
		pizza = new Circle();
		pizza2 = new Circle(10,"치즈피자");
		//3. 피자의 반지름을 10으로 설정
		//pizza.radius = 10;
		//4. 피자의 이름을 불고기피자로 설정
		//pizza.name = "불고기피자";
		//5. 피자의 면적 메소드 호출하여 알아내기
		System.out.println(pizza.name + "인 원의 면적은 " + pizza.getArea());
		System.out.println(pizza2.name);
		// 레퍼런스 변수 donut 선언
		Circle donut;
		// Circle 객체 생성
		donut = new Circle();
		// 도넛 반지름 5로 설정
		donut.radius = 5;
		// 도넛 이름을 "자바도넛"으로 설정
		donut.name = "자바도넛";
		// 도넛 면적 계산하여 출력하기
		System.out.println(donut.name + "인 원의 변적은 " + donut.getArea());
	}

}