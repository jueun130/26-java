import java.util.Scanner;

public class Ex08 {

	public static void main(String[] args) {
		// 5개 정수 입력 받아서 양수의 합을 구하시오.
		
		Scanner scanner = new Scanner(System.in);
		
		int intArray[] = new int[5]; // 배열 생성
		
		int max=0;	// 현재 가장 큰 수
		System.out.println("양수 5개를 입력하세요.");
		for(int i=0;i<5; i++) {
			intArray[i] = scanner.nextInt();	// 입력받은 정수를 배열에 저장
			if(intArray[i] > max)	// int Array[i]가 현재 가장 큰 수보다 크면
				max = intArray[i];	// int Array[i]를 max로 변경
		}
		System.out.print("가장 큰 수는" + max + "입니다.");
		
		scanner.close();
	}

}
