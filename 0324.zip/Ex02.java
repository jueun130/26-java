import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("필기시험 점수를 입력하시오: ");
		int written = scanner.nextInt();
		
		System.out.print("토익 점수를 입력하시오: ");
		int toeic = scanner.nextInt();
		
		if (written >= 80 && toeic >= 850)
			System.out.println("합격");
		else
			System.out.println("불합격");
		
		scanner.close();
		
	}

}
