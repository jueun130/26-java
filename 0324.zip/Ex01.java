import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				Scanner scanner = new Scanner(System.in);
				
				System.out.print("나이를 입력하시오: ");
				int age = scanner.nextInt();
				if (age < 18)
					System.out.println("청소년 관람 불가");
				
				scanner.close();
			
			}
		
	}


