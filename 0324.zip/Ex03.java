import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int balance = 10000; // 교통카드 잔액
		System.out.print("나이를 입력하시오: ");
		int age = scanner.nextInt(); // 정수 입력
		
		if (age >= 7 && age <= 12)
			balance -= 450;
		else if (age >= 13 && age <= 18)
			balance -= 720;
		else if (age >= 19)
			balance -= 1200;
		
		System.out.println("잔액은" + balance + "원입니다.");
		
		scanner.close();
	}

}
