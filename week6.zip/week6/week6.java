package week6;

import java.util.Scanner;

public class week6 {

    
    public static void readAndAdd(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num = scan.nextInt();
        int num2 = scan.nextInt();
        System.out.println(num + num2);
        scan.close();
    }

    
    public static int add2(int a, int b) {
        System.out.println(a + b);
        return a + b;
    }

    public static void main(String[] args) {
        
        int result = add2(50, 60);
       
        System.out.println(result);
    }

}