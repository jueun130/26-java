
public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("20221863");
		System.out.print("이주은입니다.\n java는 3번째 듣고 있습니다.");
		System.out.println("예전엔 전필이었어서 재수강 신청을 했는데");
		System.out.print("지금은 전선으로 바뀌었다는 것을");
		System.out.print("오늘 알았습니다.");
		System.out.println("졸업하고 싶습니다.");
	}

}
