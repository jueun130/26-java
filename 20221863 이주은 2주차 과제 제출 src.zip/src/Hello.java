
public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//System.out.println("Hello Java");
		System.out.print("반갑습니다.\n줄바꿨습니다.");
		System.out.println("이주은");
		//System.out.println("정보보안학과");
	}

}
