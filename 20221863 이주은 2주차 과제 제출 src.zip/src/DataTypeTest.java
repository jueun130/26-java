
public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본형 변수 선언
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 24;
		height = 157.8;
		weight = 42.3;
		
		// 3. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name;
		name = "이주은";
		String s = new String("이주은");
		
		String address;
		address = "대전광역시 중구 중촌동 현대아파트 107동 1001호";
		
		DataTypeTest dtt = new DataTypeTest();
		
		// 4. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("이름 : "+name);
		System.out.println("나이 : "+age);
		System.out.println("키 : "+height);
		System.out.println("몸무게 : "+weight);
		System.out.println("주소 : "+address);
	}

}
